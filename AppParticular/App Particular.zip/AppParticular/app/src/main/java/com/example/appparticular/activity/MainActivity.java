package com.example.appparticular.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.appparticular.R;

//ACTIVITY LOGIN
public class MainActivity extends AppCompatActivity {

    //private TextView textCadastrar;
    private Button buttonEntrar;
    private EditText campoEmail, campoSenha;
    //private ProgressBar progressBar;

    //private static FirebaseAuth autenticacao;
    //    private Usuario usuario;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        inicializarComponentes();

        buttonEntrar.setOnClickListener(v -> {
            String email = campoEmail.getText().toString();
            String senha = campoSenha.getText().toString();

            if(!email.isEmpty()){
                if(!senha.isEmpty()){
                    Toast.makeText(MainActivity.this, "Login efetuado", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(MainActivity.this, "Informe a senha", Toast.LENGTH_SHORT).show();
                }
            }else{
                Toast.makeText(MainActivity.this, "Informe o email", Toast.LENGTH_SHORT).show();
            }
        });
    }


    private void inicializarComponentes(){
        //textCadastrar = findViewById(R.id.textCadastrar);
        campoEmail = findViewById(R.id.editLoginEmail);
        campoSenha = findViewById(R.id.editLoginSenha);
        buttonEntrar = findViewById(R.id.buttonEntrar);
        //progressBar = findViewById(R.id.progressLogin);
    }

}